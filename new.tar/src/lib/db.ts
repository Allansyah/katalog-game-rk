import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

function createPrismaClient() {
  return new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  })
}

// Check if cached client has all required models
function hasAllModels(client: PrismaClient): boolean {
  return 'server' in client && 'weapon' in client
}

// In development, always create a new client if the cached one doesn't have all models
let cachedClient = globalForPrisma.prisma

if (cachedClient && !hasAllModels(cachedClient)) {
  // Disconnect old client if possible
  cachedClient.$disconnect().catch(() => {})
  cachedClient = undefined
  globalForPrisma.prisma = undefined
}

export const db = cachedClient ?? createPrismaClient()

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = db
}

// Export types
export * from '@prisma/client'
